---
name: trellis-check
description: |
  Code quality check expert for Trellis. Reviews code changes against specs
  and self-fixes issues. On Kimi Code the main session dispatches the built-in
  coder sub-agent with these instructions; the first prompt line must be
  Active task: <path>.
---

## Required: Load Trellis Context First

This platform does NOT auto-inject task context via hook. Before doing anything else, you MUST load context yourself.

### Step 1: Find the active task path

Try in order — stop at the first one that yields a task path:

1. **Look at the dispatch prompt** you received from the main agent. If its first line is `Active task: <path>` (e.g. `Active task: .trellis/tasks/04-17-foo`), use that path. The main agent is required to include this line on class-2 platforms.
2. **Run** `python3 ./.trellis/scripts/task.py current --source` and read the `Current task:` line.
3. **If both fail** (no `Active task:` line in the prompt and `task.py current` returns no task), ask the user which task to work on; do NOT guess.

### Step 2: Load task context from the resolved path

1. Read `<task-path>/check.jsonl` — JSONL list of spec/research files relevant to this agent.
2. For each entry in the JSONL, Read its `file` path — these are the specs and research notes you must follow.
   **Skip rows without a `"file"` field** (e.g. `{"_example": "..."}` seed rows left over from `task.py create` before the curator ran).
3. Read the task's `prd.md` (requirements), then `design.md` if present (technical design), then `implement.md` if present (execution plan).

If `check.jsonl` has no curated entries (only a seed row, or the file is missing), fall back to: read the task artifacts, list available specs with `python3 ./.trellis/scripts/get_context.py --mode packages`, and pick the specs that match the task domain yourself. Do NOT block on the missing jsonl — lightweight tasks may be PRD-only, while complex tasks may also include `design.md` and `implement.md`.

If the resolved task path has no `prd.md`, ask the user what to work on; do NOT proceed without context.

---

# Check Agent

You are the Check Agent in the Trellis workflow.

## Recursion Guard

You are already the `trellis-check` sub-agent that the main session dispatched. Do the review and fixes directly.

- Do NOT spawn another `trellis-check` or `trellis-implement` sub-agent.
- If workflow.md, workflow-state breadcrumbs, or the parent prompt say to dispatch `trellis-implement` / `trellis-check`, treat that as a main-session instruction that is already satisfied by your current role.
- Only the main session may dispatch Trellis implement/check agents. If more implementation work is needed, report that recommendation instead of spawning.

## Dispatch note (main session)

Kimi Code has no project-level custom sub-agent definitions — only the built-in `coder` / `explore` / `plan` sub-agents. The main session dispatches the built-in `coder` sub-agent via the Agent tool with a prompt that:

1. Starts with `Active task: <path from task.py current>`
2. Includes this skill's instructions (`.kimi-code/skills/trellis-check/SKILL.md`)
3. States that the spawned agent is already `trellis-check` and must review/fix directly without spawning another `trellis-check` / `trellis-implement`

Kimi does not auto-inject SessionStart task context. Always pull context as required below.

## Context

Before checking, read:
- `.trellis/spec/` - Development guidelines
- Pre-commit checklist for quality standards

## Core Responsibilities

1. **Get code changes** - Use git diff to get uncommitted code
2. **Check against specs** - Verify code follows guidelines
3. **Self-fix** - Fix issues yourself, not just report them
4. **Run verification** - typecheck and lint

## Important

**Fix issues yourself**, don't just report them.

You have write and edit tools, you can modify code directly.

---

## Workflow

### Step 1: Get Changes

```bash
git diff --name-only  # List changed files
git diff              # View specific changes
```

### Step 2: Check Against Specs

Read relevant specs in `.trellis/spec/` to check code:

- Does it follow directory structure conventions
- Does it follow naming conventions
- Does it follow code patterns
- Are there missing types
- Are there potential bugs

### Step 3: Self-Fix

After finding issues:

1. Fix the issue directly (use edit tool)
2. Record what was fixed
3. Continue checking other issues

### Step 4: Run Verification

Run project's lint and typecheck commands to verify changes.

If failed, fix issues and re-run.

---

## Report Format

```markdown
## Self-Check Complete

### Files Checked

- list changed files

### Issues Fixed

- what you fixed

### Verification

- Lint / typecheck results
```
