import { PostHog } from 'posthog-node';
import { machineIdSync } from 'node-machine-id';
import { app } from 'electron';
import { getSetting, setSetting } from './store';
import { logger } from './logger';

// Security (T08): the PostHog API key is NEVER hardcoded in source. It must be
// supplied at runtime via the POSTHOG_API_KEY env var (operator-provided). With
// no key present, telemetry cannot initialize and no data leaves the machine.
const POSTHOG_HOST = 'https://us.i.posthog.com';
const TELEMETRY_SHUTDOWN_TIMEOUT_MS = 1500;

let posthogClient: PostHog | null = null;
let distinctId: string = '';
// Runtime gate: true only after a successful, key-present init. Guards all sends.
let telemetryInitialized = false;

function getPostHogApiKey(): string {
  return process.env.POSTHOG_API_KEY ?? '';
}

function getCommonProperties(): Record<string, string> {
    return {
        $app_version: app.getVersion(),
        $os: process.platform,
        os_tag: process.platform,
        arch: process.arch,
    };
}

function isIgnorablePostHogShutdownError(error: unknown): boolean {
    if (!(error instanceof Error)) {
        return false;
    }

    const message = `${error.name} ${error.message}`.toLowerCase();
    if (
        message.includes('posthogfetchnetworkerror') ||
        message.includes('network error while fetching posthog') ||
        message.includes('timeouterror') ||
        message.includes('aborted due to timeout') ||
        message.includes('fetch failed')
    ) {
        return true;
    }

    return 'cause' in error && error.cause !== error
        ? isIgnorablePostHogShutdownError(error.cause)
        : false;
}

async function telemetryFetch(input: string, init?: RequestInit): Promise<Response> {
    try {
        return await fetch(input, init);
    } catch (error) {
        if (isIgnorablePostHogShutdownError(error)) {
            logger.debug('Ignored telemetry network error:', error);
            return new Response('{}', {
                status: 200,
                headers: {
                    'Content-Type': 'application/json',
                },
            });
        }
        throw error;
    }
}

/**
 * Initialize PostHog telemetry
 */
export async function initTelemetry(): Promise<void> {
  try {
    const telemetryEnabled = await getSetting('telemetryEnabled');
    if (!telemetryEnabled) {
      telemetryInitialized = false;
      logger.info('Telemetry is disabled in settings');
      return;
    }

    // Security (T08): no hardcoded key — must be provided via POSTHOG_API_KEY env.
    const apiKey = getPostHogApiKey();
    if (!apiKey) {
      telemetryInitialized = false;
      logger.info('Telemetry enabled but no PostHog API key configured (POSTHOG_API_KEY); skipping init');
      return;
    }

    // Initialize PostHog client
    posthogClient = new PostHog(apiKey, { host: POSTHOG_HOST, fetch: telemetryFetch });
    telemetryInitialized = true;

        // Get or generate machine ID
        distinctId = await getSetting('machineId');
        if (!distinctId) {
            distinctId = machineIdSync();
            await setSetting('machineId', distinctId);
            logger.debug(`Generated new machine ID for telemetry: ${distinctId}`);
        }

        const properties = getCommonProperties();

        // Check if this is a new installation
        const hasReportedInstall = await getSetting('hasReportedInstall');
        if (!hasReportedInstall) {
            posthogClient.capture({
                distinctId,
                event: 'app_installed',
                properties,
            });
            await setSetting('hasReportedInstall', true);
            logger.info('Reported app_installed event');
        }

        // Always report app opened
        posthogClient.capture({
            distinctId,
            event: 'app_opened',
            properties,
        });
        logger.debug('Reported app_opened event');

    } catch (error) {
        logger.error('Failed to initialize telemetry:', error);
    }
}

export function trackMetric(event: string, properties: Record<string, unknown> = {}): void {
    logger.info(`[metric] ${event}`, properties);
}

export function captureTelemetryEvent(event: string, properties: Record<string, unknown> = {}): void {
  if (!telemetryInitialized || !posthogClient || !distinctId) {
    return;
  }

    try {
        posthogClient.capture({
            distinctId,
            event,
            properties: {
                ...getCommonProperties(),
                ...properties,
            },
        });
    } catch (error) {
        logger.debug(`Failed to capture telemetry event "${event}":`, error);
    }
}

/**
 * Best-effort telemetry shutdown that never blocks app exit on network issues.
 */
export async function shutdownTelemetry(): Promise<void> {
  const client = posthogClient;
  posthogClient = null;
  distinctId = '';
  telemetryInitialized = false;

    if (!client) {
        return;
    }

    let didTimeout = false;
    let timeoutHandle: ReturnType<typeof setTimeout> | null = null;
    const shutdownPromise = client.shutdown().catch((error) => {
        if (isIgnorablePostHogShutdownError(error)) {
            logger.debug('Ignored telemetry shutdown network error:', error);
            return;
        }
        throw error;
    });

    try {
        await Promise.race([
            shutdownPromise,
            new Promise<void>((resolve) => {
                timeoutHandle = setTimeout(() => {
                    didTimeout = true;
                    resolve();
                }, TELEMETRY_SHUTDOWN_TIMEOUT_MS);
            }),
        ]);
        if (timeoutHandle) {
            clearTimeout(timeoutHandle);
        }

        if (didTimeout) {
            logger.debug(`Skipped waiting for telemetry shutdown after ${TELEMETRY_SHUTDOWN_TIMEOUT_MS}ms`);
            return;
        }

        logger.debug('Flushed telemetry events on shutdown');
    } catch (error) {
        if (timeoutHandle) {
            clearTimeout(timeoutHandle);
        }
        logger.error('Error shutting down telemetry:', error);
    }
}
