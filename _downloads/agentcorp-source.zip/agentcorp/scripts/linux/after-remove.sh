﻿#!/bin/bash

# Post-removal script for AgentCorp on Linux

set -e

# Remove symbolic links
rm -f /usr/local/bin/agentcorp 2>/dev/null || true
rm -f /usr/local/bin/openclaw 2>/dev/null || true

# Update desktop database
if command -v update-desktop-database &> /dev/null; then
    update-desktop-database -q /usr/share/applications || true
fi

# Update icon cache
if command -v gtk-update-icon-cache &> /dev/null; then
    gtk-update-icon-cache -q /usr/share/icons/hicolor || true
fi

# Remove AppArmor profile
APPARMOR_PROFILE_TARGET='/etc/apparmor.d/agentcorp'
if [ -f "$APPARMOR_PROFILE_TARGET" ]; then
    rm -f "$APPARMOR_PROFILE_TARGET"
fi

echo "AgentCorp has been removed."
